import "dotenv/config";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import express, { Express } from "express";

import routes from "./src/routes/index.js";
import { sequelize } from "./src/config/sequelize.js";
import middlewares from "./src/middlewares/index.js";

const app: Express = express();
const port: number = parseInt(process.env.SERVER_PORT || "4000");

app.use(helmet());
app.use(
  cors({
    origin: process.env.CORS_ORIGIN?.split(",") || ["http://localhost:3000"],
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));
app.use(express.json({ limit: "10mb" }));

app.use("/api", routes.bookRouter);
app.use("/api", routes.profileRouter);

app.use(middlewares.notFoundHandler);
app.use(middlewares.errorHandler);

sequelize
  .authenticate()
  .then(async () => {
    console.log("Database connection established successfully.");
    await sequelize.sync({ alter: false });

    app.listen(port, "0.0.0.0", () => {
      console.log(`Server is running on localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error("Failed to connect to database:", error);
    process.exit(1);
  });
