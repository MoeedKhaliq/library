import "dotenv/config";
import { sequelize } from "./src/config/sequelize.js";
import Book from "./src/models/Book.js";
import Profile from "./src/models/Profile.js";
import booksData from "./src/data/books.json" assert { type: "json" };

async function seedDatabase() {
  try {
    console.log("Starting database seed...");

    
    await sequelize.sync({ force: true });
    console.log("Database synced successfully");

    
    console.log("Seeding books...");
    await Book.bulkCreate(booksData);
    console.log(`Seeded ${booksData.length} books`);

    
    console.log("Seeding default profile...");
    await Profile.create({
      id: 1,
      name: "Library User",
      email: "user@library.com",
      favoriteGenres: ["Fiction", "Classic", "Fantasy"],
    });
    console.log("Seeded default profile");

    console.log("Database seeding completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

seedDatabase();
