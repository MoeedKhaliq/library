# Library Backend

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Setup environment variables by creating a `.env` file (see `.env.example` if available, or codebase).

3. Run database migrations:

   ```bash
   npm run migrate
   ```

4. Seed the database:

   ```bash
   npm run seed
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```
