import { DataTypes } from "sequelize";
import { sequelize } from "../config/sequelize.js";
import { Profile } from "../types/profile.js";

Profile.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: { notEmpty: true },
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: { isEmail: true },
    },
    favoriteGenres: {
      type: DataTypes.ARRAY(DataTypes.STRING),
      allowNull: true,
      defaultValue: [],
    },
  },
  { sequelize, modelName: "Profile", tableName: "profiles", timestamps: true }
);

export default Profile;
