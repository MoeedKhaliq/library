import Book from "./Book.js";
import Profile from "./Profile.js";

export { Book, Profile };
