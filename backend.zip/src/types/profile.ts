import { Model, Optional } from "sequelize";

export interface ProfileAttributes {
  id: number;
  name: string;
  email: string;
  favoriteGenres?: string[];
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ProfileCreationAttributes
  extends Optional<ProfileAttributes, "id" | "createdAt" | "updatedAt"> {}

export class Profile
  extends Model<ProfileAttributes, ProfileCreationAttributes>
  implements ProfileAttributes
{
  public id!: number;
  public name!: string;
  public email!: string;
  public favoriteGenres?: string[];
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}
