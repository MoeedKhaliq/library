import { Model, Optional } from "sequelize";

export interface BookAttributes {
  id: number;
  title: string;
  author: string;
  description: string;
  tags?: string[];
  publishedYear?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface BookCreationAttributes
  extends Optional<BookAttributes, "id" | "createdAt" | "updatedAt"> {}

export class Book
  extends Model<BookAttributes, BookCreationAttributes>
  implements BookAttributes
{
  public id!: number;
  public title!: string;
  public author!: string;
  public description!: string;
  public tags?: string[];
  public publishedYear?: number;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}
