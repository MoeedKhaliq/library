import { errorHandler } from "./errorHandler.js";
import { notFoundHandler } from "./notFoundHandler.js";

const middlewares = {
  errorHandler,
  notFoundHandler,
};

export default middlewares;
