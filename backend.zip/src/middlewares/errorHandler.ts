import { Request, Response, NextFunction } from "express";
import {
  UniqueConstraintError,
  ValidationError,
  DatabaseError,
} from "sequelize";

export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error("Error:", err);

  
  if (err instanceof ValidationError) {
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }

  if (err instanceof UniqueConstraintError) {
    return res.status(409).json({
      success: false,
      message: "Duplicate entry. This record already exists.",
    });
  }

  if (err instanceof DatabaseError) {
    return res.status(500).json({
      success: false,
      message: "Database error occurred",
    });
  }

  
  res.status(500).json({
    success: false,
    message: err.message || "Internal Server Error",
  });
};
