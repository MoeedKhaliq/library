import { bookRouter } from "./bookRoutes.js";
import { profileRouter } from "./profileRoutes.js";

const routes = {
  bookRouter,
  profileRouter,
};

export default routes;
