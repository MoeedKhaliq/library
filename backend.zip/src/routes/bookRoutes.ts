import express, { Router } from "express";
import controllers from "../controllers/index.js";

const router: Router = express.Router();

router.get("/books", controllers.bookController.getAllBooksController);
router.get("/books/:id", controllers.bookController.getBookByIdController);

export { router as bookRouter };
