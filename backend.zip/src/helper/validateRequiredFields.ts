export const validateRequiredFields = (fields: Record<string, any>) => {
  const missingFields: string[] = [];

  for (const [key, value] of Object.entries(fields)) {
    if (!value || (typeof value === "string" && value.trim() === "")) {
      missingFields.push(key);
    }
  }

  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
};
