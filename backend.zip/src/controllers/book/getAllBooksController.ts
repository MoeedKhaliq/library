import { Request, Response, NextFunction } from "express";
import Book from "../../models/Book.js";
import { Op } from "sequelize";

export const getAllBooksController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const search = req.query.search as string;

    let whereClause = {};

    
    if (search) {
      whereClause = {
        [Op.or]: [
          { title: { [Op.iLike]: `%${search}%` } },
          { author: { [Op.iLike]: `%${search}%` } },
          { description: { [Op.iLike]: `%${search}%` } },
          {
            tags: {
              [Op.overlap]: [search],
            },
          },
        ],
      };
    }

    const books = await Book.findAll({
      where: whereClause,
      order: [["title", "ASC"]],
    });

    res.status(200).json({
      success: true,
      message: search
        ? `Found ${books.length} book(s) matching "${search}"`
        : "Books retrieved successfully",
      data: books,
      count: books.length,
    });
  } catch (error: unknown) {
    next(error);
  }
};
