import * as bookController from "./book/index.js";
import * as profileController from "./profile/index.js";

const controllers = {
  bookController,
  profileController,
};

export default controllers;
