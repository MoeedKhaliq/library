import { Request, Response, NextFunction } from "express";
import Profile from "../../models/Profile.js";

export const getProfileController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    
    const profile = await Profile.findByPk(1);

    if (!profile) {
      return res.status(404).json({
        success: false,
        message: "Profile not found. Please create a profile first.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Profile retrieved successfully",
      data: profile,
    });
  } catch (error: unknown) {
    next(error);
  }
};
