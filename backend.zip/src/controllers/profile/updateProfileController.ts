import { Request, Response, NextFunction } from "express";
import Profile from "../../models/Profile.js";
import { validateRequiredFields } from "../../helper/validateRequiredFields.js";

export const updateProfileController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { name, email, favoriteGenres } = req.body;

    
    const requiredFields = { name, email };
    const validation = validateRequiredFields(requiredFields);

    if (!validation.isValid) {
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: validation.missingFields,
      });
    }

    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: "Invalid email format",
      });
    }

    
    let profile = await Profile.findByPk(1);

    if (!profile) {
      
      profile = await Profile.create({
        id: 1,
        name,
        email,
        favoriteGenres: favoriteGenres || [],
      });

      return res.status(201).json({
        success: true,
        message: "Profile created successfully",
        data: profile,
      });
    }

    
    await profile.update({
      name,
      email,
      favoriteGenres: favoriteGenres || profile.favoriteGenres,
    });

    res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      data: profile,
    });
  } catch (error: unknown) {
    next(error);
  }
};
