export interface Book {
  id: number;
  title: string;
  author: string;
  description: string;
  tags?: string[];
  publishedYear?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface Profile {
  id: number;
  name: string;
  email: string;
  favoriteGenres: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  count?: number;
}

export interface ApiError {
  success: false;
  message: string;
  errors?: string[];
}
