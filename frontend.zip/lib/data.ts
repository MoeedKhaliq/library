export const company = {
  name: "Library System",
  email: "support@library.com",
};

export const content = {
  hero: {
    title: "Welcome to the Library",
    subtitle:
      "Discover a world of knowledge with our vast collection of books.",
    buttonText: "Browse Catalog",
  },
  bestSellers: {
    title: "Featured Books",
  },
  trending: {
    content: "Explore our most popular reads this week.",
    buttonText: "View All",
  },
  categories: {
    title: "Categories",
  },
};
