import { API_URL } from "./config";
import type { Book, Profile, ApiResponse } from "./types";

class ApiService {
  private async fetchApi<T>(
    endpoint: string,
    options?: RequestInit
  ): Promise<T> {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({
        message: "An error occurred",
      }));
      throw new Error(error.message || "API request failed");
    }

    return response.json();
  }

  
  async getBooks(search?: string): Promise<ApiResponse<Book[]>> {
    const queryParam = search ? `?search=${encodeURIComponent(search)}` : "";
    return this.fetchApi<ApiResponse<Book[]>>(`/books${queryParam}`);
  }

  async getBookById(id: number): Promise<ApiResponse<Book>> {
    return this.fetchApi<ApiResponse<Book>>(`/books/${id}`);
  }

  
  async getProfile(): Promise<ApiResponse<Profile>> {
    return this.fetchApi<ApiResponse<Profile>>("/profile");
  }

  async updateProfile(
    profile: Partial<Profile>
  ): Promise<ApiResponse<Profile>> {
    return this.fetchApi<ApiResponse<Profile>>("/profile", {
      method: "PUT",
      body: JSON.stringify(profile),
    });
  }
}

export const api = new ApiService();
