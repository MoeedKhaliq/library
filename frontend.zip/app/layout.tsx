import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Theme/Header";
import { Footer } from "@/components/Theme/Footer";
import { company } from "@/lib/data";

export const metadata: Metadata = {
  title: company.name,
  description: "Library Information System",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen flex flex-col">
        <Header />
        <div className="grow">{children}</div>
        <Footer />
      </body>
    </html>
  );
}
