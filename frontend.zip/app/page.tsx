"use client";

import { useState, useEffect } from "react";
import { api } from "@/lib/api";
import type { Book } from "@/lib/types";
import BookCard from "@/components/BookCard";
import SearchBar from "@/components/SearchBar";
import LoadingSpinner from "@/components/LoadingSpinner";
import ErrorMessage from "@/components/ErrorMessage";
import { Container } from "@/components/Theme/Container";

export default function HomePage() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchBooks = async (query?: string) => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.getBooks(query);
      setBooks(response.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch books");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    fetchBooks(query);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Container>
        <div className="flex justify-between items-center mt-8">
          <h1 className="text-4xl font-bold text-gray-900">Book Catalog</h1>

          <div>
            <SearchBar
              onSearch={handleSearch}
              placeholder="Search by title, author, description, or tags..."
            />
          </div>
        </div>

        {loading && <LoadingSpinner />}

        {error && (
          <div className="mb-6">
            <ErrorMessage message={error} />
          </div>
        )}

        {!loading && !error && books.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">
              {searchQuery
                ? `No books found matching "${searchQuery}"`
                : "No books available"}
            </p>
          </div>
        )}

        {!loading && !error && books.length > 0 && (
          <>
            <p className="text-gray-600 mb-6">
              {searchQuery
                ? `Found ${books.length} book${
                    books.length !== 1 ? "s" : ""
                  } matching "${searchQuery}"`
                : `Showing ${books.length} book${
                    books.length !== 1 ? "s" : ""
                  }`}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {books.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </>
        )}
      </Container>
    </div>
  );
}
