"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { FiArrowLeft } from "react-icons/fi";
import { api } from "@/lib/api";
import type { Book } from "@/lib/types";
import LoadingSpinner from "@/components/LoadingSpinner";
import ErrorMessage from "@/components/ErrorMessage";
import { Container } from "@/components/Theme/Container";

export default function BookDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBook = async () => {
      if (!id) return;
      try {
        setLoading(true);
        
        const bookId = parseInt(id as string);
        if (isNaN(bookId)) {
          throw new Error("Invalid book ID");
        }
        const response = await api.getBookById(bookId);
        setBook(response.data);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to fetch book details"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchBook();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Container>
          <LoadingSpinner />
        </Container>
      </div>
    );
  }

  if (error || !book) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Container>
          <div className="py-8">
            <button
              onClick={() => router.back()}
              className="flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors"
            >
              <FiArrowLeft className="mr-2" />
              Back
            </button>
            <ErrorMessage message={error || "Book not found"} />
          </div>
        </Container>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Container>
        <div className="py-8">
          <Link
            href="/"
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <FiArrowLeft className="mr-2" />
            Back to Catalog
          </Link>

          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-8">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="flex-1">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">
                    {book.title}
                  </h1>
                  <p className="text-xl text-gray-600 mb-6">by {book.author}</p>

                  <div className="prose max-w-none text-gray-700 mb-8">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Description
                    </h3>
                    <p>{book.description}</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 border-t border-gray-100 pt-6">
                    {book.publishedYear && (
                      <div>
                        <span className="block text-sm font-medium text-gray-500 mb-1">
                          Published
                        </span>
                        <span className="text-gray-900">
                          {book.publishedYear}
                        </span>
                      </div>
                    )}

                    {book.tags && book.tags.length > 0 && (
                      <div className="col-span-1 sm:col-span-2">
                        <span className="block text-sm font-medium text-gray-500 mb-2">
                          Tags
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {book.tags.map((tag) => (
                            <span
                              key={tag}
                              className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full font-medium"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
