"use client";

import { useState, useEffect } from "react";
import { api } from "@/lib/api";
import type { Profile } from "@/lib/types";
import LoadingSpinner from "@/components/LoadingSpinner";
import ErrorMessage from "@/components/ErrorMessage";
import { Container } from "@/components/Theme/Container";
import { FaPen } from "react-icons/fa6";

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    favoriteGenres: [] as string[],
  });

  
  const [validationErrors, setValidationErrors] = useState<{
    name?: string;
    email?: string;
  }>({});

  const [genreInput, setGenreInput] = useState("");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.getProfile();
      setProfile(response.data);
      setFormData({
        name: response.data.name,
        email: response.data.email,
        favoriteGenres: response.data.favoriteGenres || [],
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch profile");
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    const errors: { name?: string; email?: string } = {};

    
    if (!formData.name || formData.name.trim() === "") {
      errors.name = "Name is required";
    }

    
    if (!formData.email || formData.email.trim() === "") {
      errors.email = "Email is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.email = "Please enter a valid email address";
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setSaving(true);
      setError(null);
      setSuccessMessage(null);
      const response = await api.updateProfile(formData);
      setProfile(response.data);
      setIsEditing(false);
      setSuccessMessage("Profile updated successfully!");
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        name: profile.name,
        email: profile.email,
        favoriteGenres: profile.favoriteGenres || [],
      });
    }
    setValidationErrors({});
    setIsEditing(false);
  };

  const addGenre = () => {
    if (
      genreInput.trim() &&
      !formData.favoriteGenres.includes(genreInput.trim())
    ) {
      setFormData({
        ...formData,
        favoriteGenres: [...formData.favoriteGenres, genreInput.trim()],
      });
      setGenreInput("");
    }
  };

  const removeGenre = (genre: string) => {
    setFormData({
      ...formData,
      favoriteGenres: formData.favoriteGenres.filter((g) => g !== genre),
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Container>
        <div className="flex justify-between items-center my-8">
          <h1 className="text-4xl font-bold text-gray-900">My Profile</h1>
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="px-3 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <FaPen />
            </button>
          )}
        </div>

        {error && (
          <div className="mb-6">
            <ErrorMessage message={error} />
          </div>
        )}

        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
            <p className="font-medium">{successMessage}</p>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="space-y-6">
            {}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Name <span className="text-red-600">*</span>
              </label>
              {isEditing ? (
                <>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      validationErrors.name
                        ? "border-red-500"
                        : "border-gray-300"
                    }`}
                    placeholder="Enter your name"
                  />
                  {validationErrors.name && (
                    <p className="mt-1 text-sm text-red-600">
                      {validationErrors.name}
                    </p>
                  )}
                </>
              ) : (
                <p className="text-gray-700 text-lg">{profile?.name}</p>
              )}
            </div>

            {}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Email <span className="text-red-600">*</span>
              </label>
              {isEditing ? (
                <>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      validationErrors.email
                        ? "border-red-500"
                        : "border-gray-300"
                    }`}
                    placeholder="Enter your email"
                  />
                  {validationErrors.email && (
                    <p className="mt-1 text-sm text-red-600">
                      {validationErrors.email}
                    </p>
                  )}
                </>
              ) : (
                <p className="text-gray-700 text-lg">{profile?.email}</p>
              )}
            </div>

            {}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Favorite Genres
              </label>
              {isEditing ? (
                <div>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={genreInput}
                      onChange={(e) => setGenreInput(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          addGenre();
                        }
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Add a genre (e.g., Fiction, Mystery)"
                    />
                    <button
                      type="button"
                      onClick={addGenre}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                    >
                      Add
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {formData.favoriteGenres.map((genre) => (
                      <span
                        key={genre}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm flex items-center gap-2"
                      >
                        {genre}
                        <button
                          type="button"
                          onClick={() => removeGenre(genre)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {profile?.favoriteGenres &&
                  profile.favoriteGenres.length > 0 ? (
                    profile.favoriteGenres.map((genre) => (
                      <span
                        key={genre}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                      >
                        {genre}
                      </span>
                    ))
                  ) : (
                    <p className="text-gray-500">No favorite genres set</p>
                  )}
                </div>
              )}
            </div>

            {}
            {isEditing && (
              <div className="flex gap-4 pt-4">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed"
                >
                  {saving ? "Saving..." : "Save Changes"}
                </button>
                <button
                  onClick={handleCancel}
                  disabled={saving}
                  className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>

          {}
          {profile && (profile.createdAt || profile.updatedAt) && (
            <div className="mt-8 pt-6 border-t border-gray-200">
              {profile.updatedAt && (
                <p className="text-sm text-gray-500">
                  <span className="font-semibold">Last Updated:</span>{" "}
                  {new Date(profile.updatedAt).toLocaleString()}
                </p>
              )}
            </div>
          )}
        </div>
      </Container>
    </div>
  );
}
