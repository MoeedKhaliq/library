"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi";
import { company } from "@/lib/data";
import { Container } from "./Container";

const navItems = [
  { label: "Book Catalog", href: "/" },
  { label: "My Profile", href: "/profile" },
];

export const Header: React.FC = () => {
  const pathname = usePathname();
  const [isNavOpen, setIsNavOpen] = useState(false);
  const isActive = (href: string) => pathname === href;

  return (
    <header className="sticky top-0 z-50 bg-white" style={{ height: "90px" }}>
      <Container className="h-full">
        <div className="flex h-full items-center justify-between">
          <Link href="/" className="flex items-center">
            <span
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 700,
                fontSize: "24px",
                color: "#222529",
                letterSpacing: "-0.5px",
              }}
            >
              {company.name}
            </span>
          </Link>

          <nav className="hidden items-center space-x-8 lg:flex">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-sm transition-colors duration-200"
                style={{
                  fontFamily: "'Poppins', sans-serif",
                  fontWeight: 500,
                  color: isActive(item.href) ? "#222529" : "#777777",
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex lg:hidden items-center space-x-5">
            <button
              onClick={() => setIsNavOpen(!isNavOpen)}
              className="p-2 transition-colors"
              style={{ color: "#222529" }}
            >
              {isNavOpen ? (
                <FiX className="h-6 w-6" />
              ) : (
                <FiMenu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </Container>

      {isNavOpen && (
        <div className="border-t bg-white lg:hidden">
          <Container innerClassName="space-y-4 py-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setIsNavOpen(false)}
                className="block py-2 text-base transition-colors"
                style={{
                  fontFamily: "'Poppins', sans-serif",
                  fontWeight: 500,
                  color: isActive(item.href) ? "#222529" : "#777777",
                }}
              >
                {item.label}
              </Link>
            ))}
          </Container>
        </div>
      )}
    </header>
  );
};
