"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { FiChevronRight } from "react-icons/fi";
import { content } from "@/lib/data";

export const Hero: React.FC = () => {
  return (
    <section
      className="relative overflow-hidden"
      style={{
        backgroundColor: "#E8EEF5",
        minHeight: "500px",
      }}
    >
      <div className="mx-auto max-w-[1200px] px-4 py-16 lg:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {}
          <div className="z-10 space-y-6 text-center lg:text-left">
            <h1
              className="leading-tight"
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 700,
                fontSize: "48px",
                color: "#222529",
                lineHeight: 1.2,
              }}
            >
              {content.hero.title}
            </h1>
            <p
              className="line-clamp-2"
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 400,
                fontSize: "16px",
                color: "#666666",
                lineHeight: 1.6,
              }}
            >
              {content.hero.subtitle}
            </p>
            <Link
              href="/books"
              className="group inline-flex items-center justify-center lg:justify-start"
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 500,
                fontSize: "16px",
                color: "#222529",
              }}
            >
              <span
                style={{
                  borderBottom: "2px solid #222529",
                  paddingBottom: "2px",
                }}
              >
                {content.hero.buttonText}
              </span>
              <FiChevronRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>

          {}
          <div className="relative flex h-[350px] items-center justify-center lg:h-[400px]">
            <div className="relative w-full max-w-[600px]">
              <div className="relative overflow-hidden rounded-lg shadow-xl">
                <Image
                  src="/hero-library.png"
                  alt="Library Interior"
                  width={1000}
                  height={1000}
                  className="h-auto w-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
