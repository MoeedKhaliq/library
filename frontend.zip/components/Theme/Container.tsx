import React, { FC } from "react"

interface Props {
  children:
    | React.ReactNode
    | React.ReactNode[]
    | React.ReactElement
    | React.ReactElement[]
    | string
  className?: string
  innerClassName?: string
}

export const Container: FC<Props> = (props) => {
  const { children, className = "", innerClassName = "" } = props
  return (
    <div
      className={`flex h-full w-full items-center justify-center ${className}`}
    >
      <div
        className={`w-full max-w-[1336px] overflow-x-hidden overflow-y-auto px-2 sm:px-4 lg:px-6 ${innerClassName}`}
      >
        {children}
      </div>
    </div>
  )
}
