import React from "react";
import { company } from "@/lib/data";

export const Footer: React.FC = () => {
  return (
    <footer style={{ backgroundColor: "#222529" }}>
      <div className="mx-auto max-w-[1200px] px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-6">
          <p
            style={{
              fontFamily: "'Poppins', sans-serif",
              fontSize: "14px",
              fontWeight: 400,
              color: "#999999",
            }}
          >
            {company.name} © 2026 – All Rights Reserved
          </p>
        </div>
      </div>
    </footer>
  );
};
