import Link from "next/link";
import type { Book } from "@/lib/types";

interface BookCardProps {
  book: Book;
}

export default function BookCard({ book }: BookCardProps) {
  return (
    <Link href={`/${book.id}`}>
      <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          {book.title}
        </h3>
        <p className="text-sm text-gray-600 mb-3">by {book.author}</p>
        <p className="text-gray-700 line-clamp-3 mb-4">{book.description}</p>
        <div className="flex flex-wrap gap-2">
          {book.tags?.map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
        {book.publishedYear && (
          <p className="text-sm text-gray-500 mt-3">
            Published: {book.publishedYear}
          </p>
        )}
      </div>
    </Link>
  );
}
